### 网页版录音并上传

## 包含以下功能：

- 录音、播放

- 在内存中生成 mp3 文件

- post mp3 文件到 php 服务端



## 开发工具

* Adobe Flash Builder 4.6

## Demo

[http://yangyifeng.github.io/soundRecord/](http://yangyifeng.github.io/soundRecord/)